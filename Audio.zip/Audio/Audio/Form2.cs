﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;


namespace Audio
{
    //Wav header
    struct wavHeader
    {
        public RIFF riff;
        public FMT fmt;
        public DATA data;
    }

    //reader RIFF
    struct RIFF
    {
        public byte[] chunkID;
        public int chunkSize;
        public byte[] format;
    }

    //reader Fmt
    struct FMT
    {
        public byte[] subchunkID;
        public int subchunkSize;
        public short audioFormat;
        public short numChannel;
        public int sampleRate;
        public int byteRate;
        public short blockAlign;
        public short bitsPerSample;
    }

    //reader data
    struct DATA
    {
        public byte[] subchunkID;
        public int subchunk2Size;
        public int[] data;
    }



    public partial class Form2 : Form
    {
        private wavHeader header = new wavHeader();

        public Form2()
        {
            InitializeComponent();
        }


        public void readWav(Stream stream)
        {
            BinaryReader br = new BinaryReader(stream);

            //riff
            header.riff.chunkID = br.ReadBytes(4);
            if (header.riff.chunkID[0] != 'R')
            {
                if (header.riff.chunkID[1] != 'I')
                {
                    if (header.riff.chunkID[2] != 'F')
                    {
                        if (header.riff.chunkID[3] != 'F')
                        {
                            Console.WriteLine("");
                        }

                    }
                }
            }
            header.riff.chunkSize = br.ReadInt32();
            header.riff.format = br.ReadBytes(4);
            if (header.riff.format[0] != 'W')
            {
                if (header.riff.format[1] != 'A')
                {
                    if (header.riff.format[2] != 'V')
                    {
                        if (header.riff.format[3] != 'E')
                        {
                            Console.WriteLine("");
                        }
                    }
                }
            }


            //fmt
            header.fmt.subchunkID = br.ReadBytes(4);
            if (header.fmt.subchunkID[0] != 'f')
            {
                if (header.fmt.subchunkID[1] != 'm')
                {
                    if (header.fmt.subchunkID[2] != 't')
                    {

                    }
                }
            }
            header.fmt.subchunkSize = br.ReadInt32();
            header.fmt.audioFormat = br.ReadInt16();
            header.fmt.numChannel = br.ReadInt16();
            header.fmt.sampleRate = br.ReadInt32();
            header.fmt.byteRate = br.ReadInt32();
            header.fmt.blockAlign = br.ReadInt16();
            header.fmt.bitsPerSample = br.ReadInt16();


            //data
            header.data.subchunkID = br.ReadBytes(4);
            if (header.data.subchunkID[0] != 'd')
            {
                if (header.data.subchunkID[1] != 'a')
                {
                    if (header.data.subchunkID[2] != 't')
                    {
                        if (header.data.subchunkID[3] != 'a')
                        {

                        }
                    }
                }
            }
            header.data.subchunk2Size = br.ReadInt32();

            int bytePerSample = header.fmt.bitsPerSample / 8;
            header.data.data = new int[(header.data.subchunk2Size - 8)/bytePerSample];
            for (int i = 0; i < header.data.data.Length; i++)
            {
                switch (bytePerSample)
                {
                    case 1:
                        header.data.data[i] = br.ReadByte();
                        break;
                    case 2:
                        header.data.data[i] = br.ReadInt16();
                        break;
                    case 4:
                        header.data.data[i] = br.ReadInt32();
                        break;

                }

            }
            
        }

        public void writeWav(Stream stream)
        {
            BinaryWriter br = new BinaryWriter(stream);
            
            //riff
            br.Write(header.riff.chunkID);
            br.Write(header.riff.chunkSize);
            br.Write(header.riff.format);
            
            //format
            br.Write(header.fmt.subchunkID);
            br.Write(header.fmt.subchunkSize);
            br.Write(header.fmt.audioFormat);
            br.Write(header.fmt.numChannel);
            br.Write(header.fmt.sampleRate);
            br.Write(header.fmt.byteRate);
            br.Write(header.fmt.blockAlign);
            br.Write(header.fmt.bitsPerSample);
            
            //data
            br.Write(header.data.subchunkID);
            br.Write(header.data.subchunk2Size);
            int bytePerSample = header.fmt.bitsPerSample / 8;
            for (int i = 0; i < header.data.data.Length; i++)
            {
                switch (bytePerSample)
                {
                    case 1:
                        br.Write((sbyte)header.data.data[i]);
                        break;
                    case 2:
                        br.Write((short)header.data.data[i]);
                        break;
                    case 4:
                        br.Write((int)header.data.data[i]);
                        break;
                }

            }

        }

        public void display()
        {
            for (int i = 0; i < header.data.data.Length; i++)
                this.chart1.Series["Spline"].Points.AddXY(i, header.data.data[i]);
            
            Refresh();
           
        }
        
        public void zoom()
        {
            Series series = chart2.Series[0];

            ChartArea area = chart2.ChartAreas[series.ChartArea];
            area.AxisX.Minimum = 0;
            area.AxisX.Maximum = header.data.data.Length;
            area.AxisX.ScaleView.Zoomable = false;
            area.AxisX.ScaleView.SizeType = DateTimeIntervalType.Number;
            area.AxisX.ScaleView.Zoom(0, 100 * 10);
            area.AxisX.ScrollBar.ButtonStyle = ScrollBarButtonStyles.SmallScroll;
            area.AxisX.ScaleView.SmallScrollSize = 100 * 10;

            area.AxisX.Minimum = 0;
            area.CursorX.AutoScroll = true;
            area.CursorX.IsUserEnabled = true;
            area.CursorX.IsUserSelectionEnabled = true;

            for (int i = 0; i < header.data.data.Length; i++)
                this.chart2.Series["Spline"].Points.AddXY(i, header.data.data[i]);
        }
        

            
        private double[] forwardDFT(int f)
        {
            double real = 0, imaginary = 0;
            double[] amp;
            for (int t = 0; t < header.fmt.bitsPerSample; t++)
            {
                double[] sample = forwardDFT(t);

                real += (sample[0] * Math.Cos(2 * Math.PI * f * t / header.fmt.bitsPerSample)) / header.fmt.bitsPerSample;
                imaginary += sample[1] * -Math.Sin(2 * Math.PI * f * t / header.fmt.bitsPerSample) / header.fmt.bitsPerSample;
          
            }
            amp = new double[] { real, imaginary };
                
            return amp;
          
        }
       
        private double[] inverseDFT(int t)
        {
            double[] s;
            double real = 0, imaginary = 0;
            for (int f = 0; f < header.fmt.bitsPerSample; f++)
            {
                double[] amp = forwardDFT(f);
               
                real += amp[0] * Math.Cos(2 * Math.PI * f * t / header.fmt.bitsPerSample);
                imaginary += amp[1] * Math.Sin(2 * Math.PI * f * t / header.fmt.bitsPerSample); 
            }
            s = new double[] { real, imaginary };
            return s;
        }

        
    }
}
