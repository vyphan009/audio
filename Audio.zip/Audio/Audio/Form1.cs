﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Media;
using System.IO;
using System.Runtime.InteropServices;


namespace Audio
{
    public partial class Form1 : Form
    {

        [DllImport("Dll1.dll")]
        public static extern void Record();

        Form2 form;
    
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        
        private void Open(object sender, EventArgs e)
        {
            form = new Form2();
             OpenFileDialog open = new OpenFileDialog();
             open.Filter = "File Name (*.wav) | *.wav";
             if (open.ShowDialog() == DialogResult.OK)
            {
                form.readWav(open.OpenFile());
                form.Show();
                form.display();
                form.zoom();
            }

            
        }

        private void Cut(object sender, EventArgs e)
        {
            
        }

        private void Pause(object sender, EventArgs e)
        {

        }

        private void Save(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "File Name (*.wav) | *.wav";
            if(save.ShowDialog() == DialogResult.OK)
            {
                form.writeWav(save.OpenFile());
            }
        }

        private void Record(object sender, EventArgs e)
        {
            Record();
        }

        
    }
}
