1. adds threading
how to test: you can choose threading or no threading when you do filter, then it will show the time for threading and no threading.
You have to test them seperately. Whenever you filter, only choose threading or no threading (you cannot switch between them). 
2. adds windowing
how to test: you can choose between no windowing and windowing to see the difference in frequency domain.
3. copy, cut and paste in different sample rate
