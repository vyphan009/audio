﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Media;
using System.IO;
using System.Runtime.InteropServices;


namespace Audio
{
    public partial class Form1 : Form
    {

        [DllImport("Dll1.dll")]
        public static extern void Record();

        Form2 form;
        public int[] copyData
        {
            get;
            set;
        }
        public Form1()
        {
            InitializeComponent();
        }

        
        private void Open(object sender, EventArgs e)
        {
            form = new Form2(this);
            
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "File Name (*.wav) | *.wav";
            if (open.ShowDialog() == DialogResult.OK)
            {
                form.readWav(open.OpenFile());
                form.Show();
                form.displayTimeDomain();
                form.zoom();
            }
        }

        private void Save(object sender, EventArgs e)
        {
            
        }

        private void Record(object sender, EventArgs e)
        {
            Record();
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
