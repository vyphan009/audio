﻿using System;
using System.IO;

namespace Audio
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
    private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recordToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.threadTime = new System.Windows.Forms.Label();
            this.noThreadTime = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.threadingButton = new System.Windows.Forms.RadioButton();
            this.noThreadingButton = new System.Windows.Forms.RadioButton();
            this.showTime = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.filterButton = new System.Windows.Forms.RadioButton();
            this.noWindowingButton = new System.Windows.Forms.RadioButton();
            this.windowingButton = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            this.menuStrip2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(9, 32);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            series1.Legend = "Legend1";
            series1.Name = "Spline";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(693, 246);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            // 
            // chart3
            // 
            chartArea2.AxisX.ScaleView.Zoomable = false;
            chartArea2.CursorX.IsUserEnabled = true;
            chartArea2.CursorX.IsUserSelectionEnabled = true;
            chartArea2.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart3.Legends.Add(legend2);
            this.chart3.Location = new System.Drawing.Point(9, 297);
            this.chart3.Name = "chart3";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Spline";
            this.chart3.Series.Add(series2);
            this.chart3.Size = new System.Drawing.Size(566, 277);
            this.chart3.TabIndex = 2;
            this.chart3.Text = "chart3";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "100",
            "11,025",
            "22,050",
            "44,100"});
            this.comboBox1.Location = new System.Drawing.Point(711, 58);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 3;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.freqBox);
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.recordToolStripMenuItem1});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip2.Size = new System.Drawing.Size(841, 24);
            this.menuStrip2.TabIndex = 4;
            this.menuStrip2.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.cutToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.fileToolStripMenuItem.Text = "Edit";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.Save);
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            this.cutToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.cutToolStripMenuItem.Text = "Cut";
            this.cutToolStripMenuItem.Click += new System.EventHandler(this.Cut);
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.copyToolStripMenuItem.Text = "Copy";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.Copy);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.pasteToolStripMenuItem.Text = "Paste";
            this.pasteToolStripMenuItem.Click += new System.EventHandler(this.Paste);
            // 
            // recordToolStripMenuItem1
            // 
            this.recordToolStripMenuItem1.Name = "recordToolStripMenuItem1";
            this.recordToolStripMenuItem1.Size = new System.Drawing.Size(56, 20);
            this.recordToolStripMenuItem1.Text = "Record";
            this.recordToolStripMenuItem1.Click += new System.EventHandler(this.Record);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(708, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Frequency";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(754, 551);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 7;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.saveButton);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.threadTime);
            this.groupBox1.Controls.Add(this.noThreadTime);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.threadingButton);
            this.groupBox1.Controls.Add(this.noThreadingButton);
            this.groupBox1.Controls.Add(this.showTime);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(587, 422);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 123);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Threading";
            // 
            // threadTime
            // 
            this.threadTime.AutoSize = true;
            this.threadTime.Location = new System.Drawing.Point(121, 98);
            this.threadTime.Name = "threadTime";
            this.threadTime.Size = new System.Drawing.Size(0, 13);
            this.threadTime.TabIndex = 20;
            // 
            // noThreadTime
            // 
            this.noThreadTime.AutoSize = true;
            this.noThreadTime.Location = new System.Drawing.Point(121, 73);
            this.noThreadTime.Name = "noThreadTime";
            this.noThreadTime.Size = new System.Drawing.Size(0, 13);
            this.noThreadTime.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 17);
            this.label3.TabIndex = 18;
            this.label3.Text = "Threading: ";
            // 
            // threadingButton
            // 
            this.threadingButton.AutoSize = true;
            this.threadingButton.Location = new System.Drawing.Point(9, 42);
            this.threadingButton.Name = "threadingButton";
            this.threadingButton.Size = new System.Drawing.Size(73, 17);
            this.threadingButton.TabIndex = 17;
            this.threadingButton.Text = "Threading";
            this.threadingButton.UseVisualStyleBackColor = true;
            // 
            // noThreadingButton
            // 
            this.noThreadingButton.AutoSize = true;
            this.noThreadingButton.Checked = true;
            this.noThreadingButton.Location = new System.Drawing.Point(9, 19);
            this.noThreadingButton.Name = "noThreadingButton";
            this.noThreadingButton.Size = new System.Drawing.Size(90, 17);
            this.noThreadingButton.TabIndex = 16;
            this.noThreadingButton.TabStop = true;
            this.noThreadingButton.Text = "No Threading";
            this.noThreadingButton.UseVisualStyleBackColor = true;
            // 
            // showTime
            // 
            this.showTime.AutoSize = true;
            this.showTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showTime.Location = new System.Drawing.Point(56, 80);
            this.showTime.Name = "showTime";
            this.showTime.Size = new System.Drawing.Size(0, 18);
            this.showTime.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 17);
            this.label2.TabIndex = 14;
            this.label2.Text = "No Threading: ";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.filterButton);
            this.groupBox2.Controls.Add(this.noWindowingButton);
            this.groupBox2.Controls.Add(this.windowingButton);
            this.groupBox2.Location = new System.Drawing.Point(587, 297);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 100);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Windowing";
            // 
            // filterButton
            // 
            this.filterButton.AutoSize = true;
            this.filterButton.Location = new System.Drawing.Point(9, 65);
            this.filterButton.Name = "filterButton";
            this.filterButton.Size = new System.Drawing.Size(61, 17);
            this.filterButton.TabIndex = 13;
            this.filterButton.TabStop = true;
            this.filterButton.Text = "Filtering";
            this.filterButton.UseVisualStyleBackColor = true;
            // 
            // noWindowingButton
            // 
            this.noWindowingButton.AutoSize = true;
            this.noWindowingButton.Checked = true;
            this.noWindowingButton.Location = new System.Drawing.Point(9, 19);
            this.noWindowingButton.Name = "noWindowingButton";
            this.noWindowingButton.Size = new System.Drawing.Size(95, 17);
            this.noWindowingButton.TabIndex = 17;
            this.noWindowingButton.TabStop = true;
            this.noWindowingButton.Text = "No Windowing";
            this.noWindowingButton.UseVisualStyleBackColor = true;
            // 
            // windowingButton
            // 
            this.windowingButton.AutoSize = true;
            this.windowingButton.Location = new System.Drawing.Point(9, 42);
            this.windowingButton.Name = "windowingButton";
            this.windowingButton.Size = new System.Drawing.Size(63, 17);
            this.windowingButton.TabIndex = 16;
            this.windowingButton.Text = "Triangle";
            this.windowingButton.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 606);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.chart3);
            this.Controls.Add(this.chart1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Activated += new System.EventHandler(this.Form2_Activated);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recordToolStripMenuItem1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label showTime;
        private System.Windows.Forms.RadioButton windowingButton;
        private System.Windows.Forms.RadioButton noWindowingButton;
        private System.Windows.Forms.RadioButton threadingButton;
        private System.Windows.Forms.RadioButton noThreadingButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label threadTime;
        private System.Windows.Forms.Label noThreadTime;
        private System.Windows.Forms.RadioButton filterButton;
    }
}