﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Threading;
using System.Diagnostics;

namespace Audio
{

    //Wav header
    struct wavHeader
    {
        public RIFF riff;
        public FMT fmt;
        public DATA data;
    }

    //reader RIFF
    struct RIFF
    {
        public byte[] chunkID;
        public int chunkSize;
        public byte[] format;
    }

    //reader Fmt
    struct FMT
    {
        public byte[] subchunkID;
        public int subchunkSize;
        public short audioFormat;
        public short numChannel;
        public int sampleRate;
        public int byteRate;
        public short blockAlign;
        public short bitsPerSample;
    }

    //reader data
    struct DATA
    {
        public byte[] subchunkID;
        public int subchunk2Size;
        public int[] data;
    }

    struct ThreadParam
    {
        public int startIndex;
        public int endIndex;
        public double[] filter;
        public int[] tempData;
    }



    public unsafe partial class Form2 : Form
    {
        [DllImport("Dll1.dll")]
        public static extern int Record(IntPtr handle);
        [DllImport("Dll1.dll")]
        public static extern byte** getPlayBuffer();
        [DllImport("Dll1.dll")]
        public static extern void setSampleRate(int newSampleRate);
        [DllImport("Dll1.dll")]
        public static extern int getSampleRate();
        [DllImport("Dll1.dll")]
        public static extern void setBitPerSample(int newBitsPerSample);
        [DllImport("Dll1.dll")]
        public static extern int getBitPerSample();
        [DllImport("Dll1.dll")]
        public static extern void setSize(int newSize);
        [DllImport("Dll1.dll")]
        public static extern uint getSize();
        [DllImport("Dll1.dll")]
        public static extern void SetWindow(IntPtr hwnd);

        private wavHeader header = new wavHeader();
        int[] s = { 100, 11025, 22050, 44100 };
        int i;
        double time;
        bool threadStart = false;
        static int editSampleRate;
        Form1 form;
        const int numberOfThreads = 10;

        public Form2(Form1 form1)
        {
            InitializeComponent();
            this.form = form1;
        }

        /**Read data in wave file **/

        public void readWav(Stream stream)
        {
            BinaryReader br = new BinaryReader(stream);

            //riff
            header.riff.chunkID = br.ReadBytes(4);
            if (header.riff.chunkID[0] != 'R')
            {
                if (header.riff.chunkID[1] != 'I')
                {
                    if (header.riff.chunkID[2] != 'F')
                    {
                        if (header.riff.chunkID[3] != 'F')
                        {
                            Console.WriteLine("");
                        }

                    }
                }
            }
            header.riff.chunkSize = br.ReadInt32();
            header.riff.format = br.ReadBytes(4);
            if (header.riff.format[0] != 'W')
            {
                if (header.riff.format[1] != 'A')
                {
                    if (header.riff.format[2] != 'V')
                    {
                        if (header.riff.format[3] != 'E')
                        {
                            Console.WriteLine("");
                        }
                    }
                }
            }


            //fmt
            header.fmt.subchunkID = br.ReadBytes(4);
            if (header.fmt.subchunkID[0] != 'f')
            {
                if (header.fmt.subchunkID[1] != 'm')
                {
                    if (header.fmt.subchunkID[2] != 't')
                    {

                    }
                }
            }
            header.fmt.subchunkSize = br.ReadInt32();
            header.fmt.audioFormat = br.ReadInt16();
            header.fmt.numChannel = br.ReadInt16();
            header.fmt.sampleRate = br.ReadInt32();
            header.fmt.byteRate = br.ReadInt32();
            header.fmt.blockAlign = br.ReadInt16();
            header.fmt.bitsPerSample = br.ReadInt16();
            setSampleRate(header.fmt.sampleRate);
            setBitPerSample((int)header.fmt.bitsPerSample);

            //data
            header.data.subchunkID = br.ReadBytes(4);
            if (header.data.subchunkID[0] != 'd')
            {
                if (header.data.subchunkID[1] != 'a')
                {
                    if (header.data.subchunkID[2] != 't')
                    {
                        if (header.data.subchunkID[3] != 'a')
                        {

                        }
                    }
                }
            }
            header.data.subchunk2Size = br.ReadInt32();
            int bytePerSample = header.fmt.bitsPerSample / 8;
            header.data.data = new int[header.data.subchunk2Size / bytePerSample];
            for (int i = 0; i < header.data.data.Length; i++)
            {
                switch (bytePerSample)
                {
                    case 1:
                        header.data.data[i] = br.ReadSByte();
                        break;
                    case 2:
                        header.data.data[i] = br.ReadInt16();

                        break;
                    case 4:
                        header.data.data[i] = br.ReadInt32();
                        break;
                }
            }

            setData();
            comboBox1.SelectedIndex = 0;


        }
        private void setData()
        {
            setSize(header.data.subchunk2Size);
            byte** buffer = getPlayBuffer();
            sbyte* pBuffer8 = (sbyte*)*buffer;
            short* pBuffer16 = (short*)*buffer;
            setBitPerSample(header.fmt.bitsPerSample);
            setSampleRate(header.fmt.sampleRate);

            for (int i = 0; i < header.data.data.Length; i++)
            {
                switch (header.fmt.bitsPerSample)
                {
                    case 8:
                        pBuffer8[i] = (sbyte)header.data.data[i];
                        break;
                    case 16:
                        pBuffer16[i] = (sbyte)header.data.data[i];

                        break;
                }
            }
        }
        /**Write data from wave file **/
        public void writeWav(Stream stream)
        {
            BinaryWriter br = new BinaryWriter(stream);
            //riff
            br.Write(header.riff.chunkID);
            br.Write(header.riff.chunkSize);
            br.Write(header.riff.format);

            //format
            br.Write(header.fmt.subchunkID);
            br.Write(header.fmt.subchunkSize);
            br.Write(header.fmt.audioFormat);
            br.Write(header.fmt.numChannel);
            br.Write(header.fmt.sampleRate);
            br.Write(header.fmt.byteRate);
            br.Write(header.fmt.blockAlign);
            br.Write(header.fmt.bitsPerSample);

            //data
            br.Write(header.data.subchunkID);
            br.Write(header.data.subchunk2Size);

            int bytePerSample = header.fmt.bitsPerSample / 8;
            for (int i = 0; i < header.data.data.Length; i++)
            {
                switch (bytePerSample)
                {
                    case 1:
                        br.Write((sbyte)header.data.data[i]);
                        break;
                    case 2:
                        br.Write((short)header.data.data[i]);
                        break;
                    case 4:
                        br.Write((int)header.data.data[i]);
                        break;
                }

            }

        }

        /**Display waveform in chart **/
        public void displayTimeDomain()
        {
            this.chart1.Series["Spline"].Points.Clear();
            for (int i = 0; i < header.data.data.Length; i++)
                this.chart1.Series["Spline"].Points.AddXY(i, header.data.data[i]);

            Refresh();

        }
        private void displayFreqDomain()
        {
            Series series = chart3.Series[0];
            series.Points.Clear();
            ChartArea area = chart3.ChartAreas[series.ChartArea];
            area.AxisX.Minimum = 0;
            area.AxisX.Maximum = header.fmt.sampleRate;
            double f = (double)header.fmt.sampleRate / fourier.Count();
            for (int i = 0; i < fourier.Count(); i++)
                series.Points.AddXY((int)(i * f), getDistance(fourier[i]));

            Refresh();
        }
        // zoom in and out
        public void zoom()
        {
            Series series = chart1.Series[0];

            ChartArea area = chart1.ChartAreas[series.ChartArea];
            area.AxisX.Minimum = 0;
            area.AxisX.Maximum = header.data.data.Length;
            area.AxisX.ScaleView.Zoomable = false;
            area.AxisX.ScaleView.SizeType = DateTimeIntervalType.Number;
            area.AxisX.ScaleView.Zoom(0, s[i]);
            area.AxisX.ScrollBar.ButtonStyle = ScrollBarButtonStyles.SmallScroll;
            area.AxisX.ScaleView.SmallScrollSize = s[i];

            area.AxisX.Minimum = 0;
            area.CursorX.AutoScroll = true;
            area.CursorX.IsUserEnabled = true;
            area.CursorX.IsUserSelectionEnabled = true;


        }



        //=================================================================FEARTURES==========================================================
        //forward and inverse DFT
        private List<double[]> fourier = new List<double[]>();

        private double[] getSample()
        {
            Series series = chart1.Series[0];
            ChartArea area = chart1.ChartAreas[series.ChartArea];

            int start = (int)area.CursorX.SelectionStart;
            int end = (int)area.CursorX.SelectionEnd;

            if (start > end)
            {
                int temp = start;
                start = end;
                end = temp;
            }
            double[] sample = new double[end - start];
            for (int i = 0; i < sample.Length; i++)
            {
                sample[i] = header.data.data[i + start];
            }
            return sample;
        }
        private void dataAfterFourier(double[] sample)
        {

            fourier.Clear();

            for (int i = 0; i < sample.Length; i++)
            {
                fourier.Add(forwardDFT(sample, i));

            }
        }

        private double[] forwardDFT(double[] sample, int f)
        {

            double real = 0, imaginary = 0;
            double[] amp;
            for (int t = 0; t < sample.Length; t++)
            {
                real += (sample[t] * Math.Cos(2 * Math.PI * f * t / sample.Length)) / sample.Length;
                imaginary += (sample[t] * - Math.Sin(2 * Math.PI * f * t / sample.Length)) / sample.Length;

            }
            amp = new double[] { real, imaginary };

            return amp;

        }

        private double inverseDFT(List<double[]> amp, int t)
        {

            double s = 0;

            for (int f = 0; f < amp.Count(); f++)
            {
                s += amp[f][0] * Math.Cos(2 * Math.PI * f * t / amp.Count())
                   - amp[f][1] * Math.Sin(2 * Math.PI * f * t / amp.Count());
            }
            return s;
        }

        private double getDistance(double[] arr)
        {
            return Math.Sqrt(Math.Pow(arr[0], 2) + Math.Pow(arr[1], 2));
        }



        // filtering

        private void dataAfterFilter()
        {
            double diff = (double)header.fmt.sampleRate / fourier.Count;
            Series series = chart3.Series[0];
            ChartArea area = chart3.ChartAreas[series.ChartArea];

            int start = (int)(area.CursorX.SelectionStart / diff);
            int end = (int)(area.CursorX.SelectionEnd / diff);

            if (start > end)
            {
                int temp = start;
                start = end;
                end = temp;
            }

            end = Math.Min(end, fourier.Count / 2);
            if (start >= end)
            {
                return;
            }

            List<double[]> bfFilter = new List<double[]>();
            if (end < fourier.Count / 2)
            {
                for (int i = 0; i < fourier.Count / 2; i++)
                {
                    if (i < start)
                        bfFilter.Add(new double[2]);
                    else if (i < end)
                    {
                        double[] temp1 = new double[2];
                        temp1[0] = 1;
                        bfFilter.Add(temp1);
                    }
                    else
                    {

                        bfFilter.Add(new double[2]);
                    }

                }
                for (int i = fourier.Count / 2; i < fourier.Count; i++)
                {
                    if (i < fourier.Count - end)
                    {
                        bfFilter.Add(new double[2]);
                    }
                    else if (i < fourier.Count - start)
                    {
                        double[] temp2 = new double[2];
                        temp2[0] = 1;
                        bfFilter.Add(temp2);
                    }
                    else
                    {
                        bfFilter.Add(new double[2]);
                    }
                }

                double[] afFiltering = new double[bfFilter.Count];
                for (int i = 0; i < bfFilter.Count; i++)
                {
                    afFiltering[i] = inverseDFT(bfFilter, i);
                }
                if (threadStart == true)
                {
                    Threading(afFiltering);
                }
                else
                {
                    convolution(afFiltering);
                }

            }

        }

        private void Threading(double[] afFiltering)
        {
            Stopwatch watch = new Stopwatch();
            watch.Start();
            Thread[] thread = new Thread[numberOfThreads];
            int length = header.data.data.Length / 10;

            for (int i = 0; i < numberOfThreads; i++)
            {
                ThreadParam threadParam = new ThreadParam();
                threadParam.startIndex = length * i;
                if (i == numberOfThreads - 1)
                {
                    threadParam.endIndex = header.data.data.Length;
                }
                else
                {
                    threadParam.endIndex = threadParam.startIndex + length;
                }

                threadParam.filter = afFiltering;
                threadParam.tempData = new int[afFiltering.Length];

                for (int k = 0; k < afFiltering.Length; k++)
                {
                    if (threadParam.endIndex == header.data.data.Length)
                    {
                        break;
                    }
                    threadParam.tempData[k] = header.data.data[k + threadParam.endIndex];
                }


                ParameterizedThreadStart startThread = new ParameterizedThreadStart(convolutionInThreading);
                thread[i] = new Thread(startThread);
                thread[i].Start(threadParam);
            }

            for (int i = 0; i < numberOfThreads; i++)
            {
                thread[i].Join();
            }

            watch.Stop();
            time = 0;
            time = watch.ElapsedMilliseconds;
            threadTime.Text = time.ToString() + " ms" ;
            noThreadTime.Text = "0 ms";
        }
        private void convolutionInThreading(object o) {
            ThreadParam threadParam =(ThreadParam) o;

            for (int i = threadParam.startIndex; i<threadParam.endIndex; i++)
            {   
                double tempVal = 0;
                for (int k = 0; k < threadParam.filter.Length; k++)
                {
                    int index = i + k;
                    if (index < threadParam.endIndex)
                    {
                        tempVal += header.data.data[index] * threadParam.filter[k];
                    } else
                    {
                        tempVal += threadParam.tempData[index - threadParam.endIndex] * threadParam.filter[k];
                    }
                }
                header.data.data[i] = (int)tempVal;
            }

        }

        private void convolution(double[] afFiltering)
        {
            Stopwatch watch = new Stopwatch();
            watch.Start();
            for (int i = 0; i < header.data.data.Length; i++)
            {
                double tempVal = 0;
                int index = i;
                for (int k = 0; k < afFiltering.Length && index < header.data.data.Length; k++)
                {
                    tempVal += header.data.data[index] * afFiltering[k];
                    index++;
                }
                header.data.data[i] = (int)tempVal;
            }

            watch.Stop();
            time = 0;
            time = watch.ElapsedMilliseconds;
            noThreadTime.Text = time.ToString() + " ms";
            threadTime.Text = "0 ms";
        }

        //windowing
        /** Triangle window formula**/
        private double windowing(int length, int index)
        {
            double w = 0 ;
            
            w = (2.0 / length) * ((length / 2.0) - Math.Abs(index - ((length - 1.0)/2.0)));
            return w;
        }

        /**Data after windowing**/
        private void dataAfterWindowing(double[] sample)
        {

            double[] windowData = new double[sample.Length];
            for (int i = 0; i < sample.Length; i++)
            {
               windowData[i] =  windowing(sample.Length, i);
            }

            for(int i = 0; i < sample.Length; i++)
                sample[i] *= windowData[i];
        }

        //=========================================================EDIT======================================================================
        // Save wav file
        /**Save the wave file**/
        private void Save(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "File Name (*.wav) | *.wav";
            if (save.ShowDialog() == DialogResult.OK)
            {
                writeWav(save.OpenFile());
            }
        }

        //cut, copy, paste
        /** Copy**/
        private void Copy(object sender, EventArgs e)
        {
            Series series = chart1.Series[0];
            ChartArea area = chart1.ChartAreas[series.ChartArea];

            int start = (int)area.CursorX.SelectionStart;
            int end = (int)area.CursorX.SelectionEnd;
            if (start == end)
                return;

            if (start > end)
            {
                int temp = start;
                start = end;
                end = temp;
            }


            form.copyData = new int[end - start];
            for (int i = 0; i < form.copyData.Length; i++)
            {
                form.copyData[i] = header.data.data[i + start];
            }

            editSampleRate = header.fmt.sampleRate;
        }

        /**Cut**/
        private void Cut(object sender, EventArgs e)
        {
            
            Series series = chart1.Series[0];
            ChartArea area = chart1.ChartAreas[series.ChartArea];

            int start = (int)area.CursorX.SelectionStart;
            int end = (int)area.CursorX.SelectionEnd;
            if (start == end)
                return;

            if (start > end)
            {
                int temp = start;
                start = end;
                end = temp;
            }
            

            form.copyData = new int[end - start];
            for (int i = 0; i < form.copyData.Length; i++)
            {
                form.copyData[i] = header.data.data[i + start];
            }

            int[] newData = new int[header.data.data.Length - form.copyData.Length];

            for (int i = 0; i < start; i++)
            {
                newData[i] = header.data.data[i];
            }

            for(int i = end; i < newData.Length; i++)
            {
                newData[i-form.copyData.Length] = header.data.data[i];
            }

            header.data.subchunk2Size = (newData.Length * header.fmt.bitsPerSample) / 8;
            header.riff.chunkSize = 36 + header.data.subchunk2Size;
            header.data.data = newData;
            editSampleRate = header.fmt.sampleRate;
            setData();
            displayTimeDomain();
        }

        private double lerp(double p0, double p1, double t)
        {
            return p0 + (p1 - p0) * t;
        }
        /**Paste **/ 
        private void Paste(object sender, EventArgs e)
        {
            Series series = chart1.Series[0];
            ChartArea area = chart1.ChartAreas[series.ChartArea];

            int start = (int)area.CursorX.SelectionStart;
            int end = (int)area.CursorX.SelectionEnd;

            double[] tempData = new double[form.copyData.Length];
            for (int i = 0; i < form.copyData.Length; i++)
            {
                tempData[i] = (double)form.copyData[i];
            }

            if ( form.copyData != null)
            {                
                int n;
                int[] newData;
                int index = start + form.copyData.Length;

                if (header.fmt.sampleRate < editSampleRate)
                {
                    n = editSampleRate / header.fmt.sampleRate;
                    newData = new int[header.data.data.Length + form.copyData.Length / n];
                    index = start + form.copyData.Length / n;
                    List<double[]> bfFilter = new List<double[]>();
                    int filterStart = 0;
                    int filterEnd = tempData.Length / 2 / n;
                    // lowpass filter
                    for (int i = 0; i < tempData.Length / 2; i++)
                    {
                        if (i < filterStart)
                            bfFilter.Add(new double[2]);
                        else if (i < filterEnd)
                        {
                            bfFilter.Add(forwardDFT(tempData, i));
                        }
                        else
                        {
                            bfFilter.Add(new double[2]);
                        }
                    }
                    for (int i = tempData.Length / 2; i < tempData.Length; i++)
                    {
                        if (i < tempData.Length - filterEnd)
                        {
                            bfFilter.Add(new double[2]);
                        }
                        else if (i < tempData.Length - filterStart)
                        {
                            bfFilter.Add(forwardDFT(tempData, i));
                        }
                        else
                        {
                            bfFilter.Add(new double[2]);
                        }
                    }

                    double[] filteredCopyData = new double[bfFilter.Count];
                    for (int i = 0; i < bfFilter.Count; i++)
                    {
                        filteredCopyData[i] = inverseDFT(bfFilter, i);
                    }
                    // downsample
                    for (int i = 0; i < filteredCopyData.Length / n; i++)
                    {
                        newData[i + start] = (int)filteredCopyData[i / n];

                    }

                }
                else if(header.fmt.sampleRate > editSampleRate && editSampleRate != 0)
                {
                    n = header.fmt.sampleRate / editSampleRate;
                    newData = new int[header.data.data.Length + form.copyData.Length * n];
                    index = start + form.copyData.Length * n;
                    // upsampling
                    double[] temp = new double[tempData.Length * n];

                    for(int i = 0; i < temp.Length; i++)
                    {
                        int tempDataIndex = i / n;
                        if(tempDataIndex == tempData.Length - 1)
                        {
                            temp[i] = tempData[tempDataIndex];
                        }
                        else
                        {
                            temp[i] = lerp(tempData[tempDataIndex], tempData[tempDataIndex + 1], (double)((i % n) / n));
                        }
                    }

                    List<double[]> bfFilter = new List<double[]>();
                    int filterStart = 0;
                    int filterEnd = temp.Length / 2 / n;
                    // lowpass filter
                    for (int i = 0; i < temp.Length / 2; i++)
                    {
                        if (i < filterStart)
                            bfFilter.Add(new double[2]);
                        else if (i < filterEnd)
                        {
                            bfFilter.Add(forwardDFT(temp, i));
                        }
                        else
                        {
                            bfFilter.Add(new double[2]);
                        }
                    }
                    for (int i = temp.Length / 2; i < temp.Length; i++)
                    {
                        if (i < temp.Length - filterEnd)
                        {
                            bfFilter.Add(new double[2]);
                        }
                        else if (i < temp.Length - filterStart)
                        {
                            bfFilter.Add(forwardDFT(temp, i));
                        }
                        else
                        {
                            bfFilter.Add(new double[2]);
                        }
                    }

                    double[] filteredCopyData = new double[bfFilter.Count];
                    for (int i = 0; i < bfFilter.Count; i++)
                    {
                        filteredCopyData[i] = inverseDFT(bfFilter, i);
                    }

                    for (int i = 0; i < filteredCopyData.Length; i++)
                    {
                        newData[i + start] = (int)filteredCopyData[i];
                    }
                }
                else 
                {
                    newData = new int[header.data.data.Length + form.copyData.Length];
                    index = start + form.copyData.Length;
                    for(int i = 0; i < form.copyData.Length; i++)
                    {
                        newData[i + start] = form.copyData[i];
                    }
                }

                for (int i = 0; i < start; i++)
                {
                    newData[i] = header.data.data[i];
                }

                for (int i = end; i < header.data.data.Length; i++, index++)
                {
                    newData[index] = header.data.data[i];
                }

                header.data.subchunk2Size = (newData.Length * header.fmt.bitsPerSample) / 8;
                header.riff.chunkSize = 36 * header.data.subchunk2Size;
                header.data.data = newData;
                setData();
                displayTimeDomain();
            }
        }
        
        // Recording
        /**Read recored data**/
        private void readRecording()
        {
            this.header.fmt.numChannel = 1;
            this.header.fmt.bitsPerSample = (short)getBitPerSample();
            this.header.fmt.sampleRate = getSampleRate();
            this.header.fmt.blockAlign = (short)(this.header.fmt.bitsPerSample / 8);
            this.header.data.subchunk2Size = (int)getSize();
            uint size = getSize() / (uint)this.header.fmt.blockAlign;
            int[] newData = new int[size];
            if (this.header.fmt.bitsPerSample == 8)
            {
                sbyte* pData = (sbyte*)*getPlayBuffer();
                for (int i = 0; i < size; i++)
                {
                    newData[i] = pData[i];
                }
            } else if (this.header.fmt.bitsPerSample == 16)
            {
                short* pData = (short*)*getPlayBuffer();
                for (int i = 0; i < size; i++)
                {
                    newData[i] = pData[i];
                }
            }

            this.header.data.data = newData;
            displayTimeDomain();
        }
       

        const int WM_USER = 0X400;
        protected override void WndProc(ref Message m)
        {
            
            getPlayBuffer();
            switch (m.Msg)
            {
                case WM_USER:
                    readRecording();
                    break;
            }
            base.WndProc(ref m);
        }

        private void Record(object sender, EventArgs e)
        {
            Record(this.Handle);
            
        }

        // combo boxes
        /**Box for frequency **/
        private void freqBox(object sender, EventArgs e)
        {
            i = comboBox1.SelectedIndex;
            zoom();
        }
        /**Doing Fourier **/ 
        private void Fourier(object sender, EventArgs e)
        {
            double[] sample = getSample();
            dataAfterFourier(sample);
            displayFreqDomain();
        }

        /**Filtering **/ 
        private void Filter(object sender, EventArgs e)
        {
            dataAfterFilter();
            Series series = chart1.Series[0];
            ChartArea area = chart1.ChartAreas[series.ChartArea];
            area.AxisX.Minimum = 0;
            area.AxisX.Maximum = header.fmt.sampleRate;
            displayTimeDomain();

        }

        /**Windowing **/
        private void Window(object sender, EventArgs e)
        {
            double[] sample = getSample();
            dataAfterWindowing(sample);
            Series series = chart1.Series[0];
            ChartArea area = chart1.ChartAreas[series.ChartArea];
            area.AxisX.Minimum = 0;
            area.AxisX.Maximum = header.fmt.sampleRate;
            displayTimeDomain();
        }

        
        /**Save choosed option **/
        private void saveButton(object sender, EventArgs e)
        {
            double[] sample = getSample();

            if (windowingButton.Checked)
            {
                dataAfterWindowing(sample);
                dataAfterFourier(sample);
                displayFreqDomain();

            } else if (noWindowingButton.Checked)
            {
                dataAfterFourier(sample);
                displayFreqDomain();

            }

            if (filterButton.Checked)
            {
                dataAfterFilter();
                Series series = chart1.Series[0];
                ChartArea area = chart1.ChartAreas[series.ChartArea];
                area.AxisX.Minimum = 0;
                area.AxisX.Maximum = header.fmt.sampleRate;
                displayTimeDomain();
                

            }

            if (threadingButton.Checked)
            {
                threadStart = true;
            }
            else if (noThreadingButton.Checked)
            {
                threadStart = false;
            }

        }

        private void Form2_Activated(object sender, EventArgs e)
        {
            SetWindow(this.Handle);
            setData();
        }
    }
}
